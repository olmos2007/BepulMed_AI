import { useRef, useState } from "react";
import { createWorker } from "tesseract.js";

type ScanKind = "prescription" | "lab" | "document" | "unknown";

const copy = {
  ru: {
    eyebrow: "МЕДИЦИНСКИЕ ДОКУМЕНТЫ",
    title: "Умный сканер рецептов и анализов",
    intro: "Сфотографируйте документ или выберите изображение. Распознавание текста выполняется в браузере.",
    camera: "Сфотографировать",
    gallery: "Выбрать изображение",
    working: "Распознаю текст…",
    scan: "Распознать документ",
    preparing: "Подготовка распознавания…",
    processing: "Обрабатываю изображение…",
    done: "Распознавание завершено",
    retry: "Распознать ещё раз",
    clear: "Очистить",
    copy: "Копировать текст",
    extracted: "Распознанный текст",
    type: "Предполагаемый тип документа",
    prescription: "Рецепт или назначение",
    lab: "Результаты лабораторных анализов",
    document: "Медицинский документ",
    unknown: "Тип документа не определён",
    empty: "Текст не найден. Попробуйте сделать более чёткое фото при хорошем освещении.",
    limit: "Файл слишком большой. Максимальный размер — 10 МБ.",
    format: "Выберите изображение JPG, PNG, WEBP или HEIC, поддерживаемое браузером.",
    error: "Не удалось распознать документ. Проверьте подключение к интернету и попробуйте ещё раз.",
    privacyTitle: "Конфиденциальность",
    privacy: "Изображение обрабатывается локально в браузере и не отправляется в API BepulMed. Для OCR загружаются языковые данные Tesseract. Не используйте чужие документы без разрешения.",
    safetyTitle: "Важно для безопасности",
    safety: "Сканер только извлекает текст. Он может ошибаться в названиях препаратов, дозировках и числах. Не начинайте, не отменяйте и не меняйте лечение по результату OCR. Сверьте данные с оригиналом и уточните назначения у врача или фармацевта.",
    noDiagnosis: "Сканер не ставит диагнозы и не оценивает состояние здоровья.",
    selectHint: "Поддерживаются фотографии рецептов, назначений и лабораторных бланков.",
    progress: "Прогресс",
  },
  uz: {
    eyebrow: "TIBBIY HUJJATLAR",
    title: "Retsept va tahlillar uchun aqlli skaner",
    intro: "Hujjatni suratga oling yoki rasmni tanlang. Matn brauzerning o‘zida tanib olinadi.",
    camera: "Suratga olish",
    gallery: "Rasm tanlash",
    working: "Matn tanilmoqda…",
    scan: "Hujjatni tanish",
    preparing: "Tanib olish tayyorlanmoqda…",
    processing: "Rasm qayta ishlanmoqda…",
    done: "Matnni tanish tugadi",
    retry: "Qayta tanish",
    clear: "Tozalash",
    copy: "Matnni nusxalash",
    extracted: "Tanilgan matn",
    type: "Hujjatning taxminiy turi",
    prescription: "Retsept yoki tavsiya",
    lab: "Laboratoriya tahlillari natijalari",
    document: "Tibbiy hujjat",
    unknown: "Hujjat turi aniqlanmadi",
    empty: "Matn topilmadi. Yaxshi yorug‘likda aniqroq suratga oling.",
    limit: "Fayl juda katta. Maksimal hajm — 10 MB.",
    format: "JPG, PNG, WEBP yoki brauzer qo‘llaydigan HEIC rasmini tanlang.",
    error: "Hujjatni tanib bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.",
    privacyTitle: "Maxfiylik",
    privacy: "Rasm brauzer ichida qayta ishlanadi va BepulMed API serveriga yuborilmaydi. OCR uchun Tesseract til ma’lumotlari yuklanadi. Ruxsatsiz boshqa odamning hujjatidan foydalanmang.",
    safetyTitle: "Xavfsizlik muhim",
    safety: "Skaner faqat matnni ajratib oladi. Dori nomlari, dozalar va raqamlarda xato qilishi mumkin. OCR natijasiga qarab davolanishni boshlamang, to‘xtatmang yoki o‘zgartirmang. Ma’lumotlarni asl hujjat bilan solishtiring va shifokor yoki farmatsevt bilan aniqlashtiring.",
    noDiagnosis: "Skaner tashxis qo‘ymaydi va sog‘liq holatini baholamaydi.",
    selectHint: "Retseptlar, shifokor tavsiyalari va laboratoriya blanklari rasmlari qo‘llab-quvvatlanadi.",
    progress: "Jarayon",
  },
} as const;

function classify(text: string): ScanKind {
  const value = text.toLocaleLowerCase();
  if (/(референсн|референтн|гемоглобин|лейкоцит|эритроцит|биохими|анализ крови|анализ мочи|umumiy qon|gemoglobin|leykotsit|eritrotsit|tahlil natija|blood test|urine test|reference range|hemoglobin|leukocyte|erythrocyte)/i.test(value)) return "lab";
  if (/(рецепт|назначени|таблет|капсул|принимать|дозиров|Rp\.|retsept|dori vosita|kuniga|qabul qilish|prescription|take one|dosage|medication)/i.test(value)) return "prescription";
  if (text.trim().length > 20) return "document";
  return "unknown";
}

export function MedicalScanner({ lang }: { lang: "ru" | "uz" }) {
  const L = copy[lang];
  const cameraRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [text, setText] = useState("");
  const [kind, setKind] = useState<ScanKind>("unknown");
  const [status, setStatus] = useState("");
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function reset() {
    if (preview) URL.revokeObjectURL(preview);
    setFile(null);
    setPreview("");
    setText("");
    setKind("unknown");
    setStatus("");
    setProgress(0);
    setError("");
    if (cameraRef.current) cameraRef.current.value = "";
    if (galleryRef.current) galleryRef.current.value = "";
  }

  function choose(next: File | undefined) {
    if (!next) return;
    setError("");
    if (next.size > 10 * 1024 * 1024) {
      setError(L.limit);
      return;
    }
    if (!next.type.startsWith("image/")) {
      setError(L.format);
      return;
    }
    if (preview) URL.revokeObjectURL(preview);
    setFile(next);
    setPreview(URL.createObjectURL(next));
    setText("");
    setKind("unknown");
    setStatus("");
    setProgress(0);
  }

  async function recognize() {
    if (!file || busy) return;
    setBusy(true);
    setError("");
    setProgress(0);
    setStatus(L.preparing);
    let worker: Awaited<ReturnType<typeof createWorker>> | null = null;
    try {
      // OCR runs in the browser. The source image is not posted to the BepulMed API.
      // Движок и языковые модели лежат в самом приложении (public/ocr) — без CDN и без интернета.
      const ocr = `${import.meta.env.BASE_URL}ocr`;
      worker = await createWorker("rus+eng+uzb", 1, {
        workerPath: `${ocr}/worker.min.js`,
        corePath: `${ocr}/core`,
        langPath: `${ocr}/lang`,
        gzip: true,
        workerBlobURL: false,
        logger: (message) => {
          if (message.status) setStatus(message.status === "recognizing text" ? L.processing : L.preparing);
          if (typeof message.progress === "number") setProgress(Math.round(message.progress * 100));
        },
      });
      const result = await worker.recognize(file);
      const recognized = result.data.text.trim();
      setText(recognized);
      setKind(classify(recognized));
      setStatus(L.done);
      if (!recognized) setError(L.empty);
    } catch {
      setError(L.error);
      setStatus("");
    } finally {
      if (worker) await worker.terminate();
      setBusy(false);
    }
  }

  async function copyText() {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      setError(lang === "ru" ? "Не удалось скопировать текст в этом браузере." : "Bu brauzerda matnni nusxalab bo‘lmadi.");
    }
  }

  const kindLabel = kind === "lab" ? L.lab : kind === "prescription" ? L.prescription : kind === "document" ? L.document : L.unknown;

  return (
    <div className="h-full overflow-y-auto p-3 pb-5">
      <div className="rounded-2xl bg-[var(--card)] p-4">
        <div className="mb-2 text-[10px] font-bold tracking-[0.16em] text-[var(--link)]">{L.eyebrow}</div>
        <h1 className="text-xl font-bold leading-tight">{L.title}</h1>
        <p className="mt-2 text-sm text-[var(--hint)]">{L.intro}</p>
        <p className="mt-2 text-xs text-[var(--hint)]">{L.selectHint}</p>

        <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => choose(e.target.files?.[0])} />
        <input ref={galleryRef} type="file" accept="image/*" className="hidden" onChange={(e) => choose(e.target.files?.[0])} />

        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={() => cameraRef.current?.click()} className="rounded-xl bg-[var(--btn)] px-3 py-3 text-sm font-semibold text-[var(--btn-text)]">
            📷 {L.camera}
          </button>
          <button onClick={() => galleryRef.current?.click()} className="rounded-xl border border-black/15 px-3 py-3 text-sm font-semibold">
            🖼️ {L.gallery}
          </button>
        </div>

        {preview && (
          <div className="mt-4 overflow-hidden rounded-xl border border-black/10">
            <img src={preview} alt="Предпросмотр медицинского документа" className="max-h-72 w-full bg-white object-contain" />
            <div className="flex gap-2 p-2">
              <button disabled={busy} onClick={() => void recognize()} className="flex-1 rounded-lg bg-[var(--btn)] px-3 py-2 text-sm font-semibold text-[var(--btn-text)] disabled:opacity-50">
                {busy ? L.working : text ? L.retry : L.scan}
              </button>
              <button disabled={busy} onClick={reset} className="rounded-lg border border-black/15 px-3 py-2 text-sm">{L.clear}</button>
            </div>
          </div>
        )}

        {busy && (
          <div className="mt-3">
            <div className="flex justify-between text-xs text-[var(--hint)]"><span>{status}</span><span>{progress}%</span></div>
            <div className="mt-1 h-2 overflow-hidden rounded-full bg-black/10">
              <div className="h-full rounded-full bg-[var(--link)] transition-all" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}
        {!busy && status && <p className="mt-3 text-xs text-[var(--link)]">{status}</p>}
        {error && <p role="alert" className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{error}</p>}
      </div>

      {text && (
        <div className="mt-3 rounded-2xl border border-black/10 p-4">
          <div className="text-xs font-semibold text-[var(--hint)]">{L.type}</div>
          <div className="mt-1 text-sm font-semibold">{kindLabel}</div>
          <div className="mt-4 flex items-center justify-between gap-2">
            <h2 className="font-bold">{L.extracted}</h2>
            <button onClick={() => void copyText()} className="rounded-lg border border-black/15 px-3 py-2 text-xs font-medium">📋 {L.copy}</button>
          </div>
          <textarea readOnly value={text} className="mt-2 min-h-56 w-full resize-y rounded-xl bg-[var(--card)] p-3 text-sm leading-relaxed outline-none" />
          <p className="mt-2 text-xs text-[var(--hint)]">{L.noDiagnosis}</p>
        </div>
      )}

      <div className="mt-3 rounded-2xl border border-amber-300/60 bg-amber-50 p-4 text-amber-950">
        <div className="text-sm font-bold">⚠️ {L.safetyTitle}</div>
        <p className="mt-1 text-xs leading-relaxed">{L.safety}</p>
      </div>
      <div className="mt-3 rounded-2xl bg-[var(--card)] p-4">
        <div className="text-sm font-bold">🔒 {L.privacyTitle}</div>
        <p className="mt-1 text-xs leading-relaxed text-[var(--hint)]">{L.privacy}</p>
      </div>
    </div>
  );
}
