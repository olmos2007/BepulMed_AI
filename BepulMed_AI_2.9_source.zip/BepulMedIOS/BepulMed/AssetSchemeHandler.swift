import Foundation
import WebKit

/// Раздаёт собранный интерфейс из папки www внутри приложения: bepulmed://app/<путь>.
/// Всё локально — интерфейс, OCR-модели, данные Ташкента работают без интернета.
final class AssetSchemeHandler: NSObject, WKURLSchemeHandler {
    static let scheme = "bepulmed"
    private let root: URL? = Bundle.main.resourceURL?.appendingPathComponent("www", isDirectory: true)
    private var stopped = Set<ObjectIdentifier>()
    private let io = DispatchQueue(label: "bm.assets", qos: .userInitiated, attributes: .concurrent)

    static func assetPath(_ raw: String) -> String? {
        var p = raw.removingPercentEncoding ?? raw
        while p.hasPrefix("/") { p.removeFirst() }
        if p.contains("..") || p.contains("\\") { return nil } // за пределы www не выходим
        if p.isEmpty { return "index.html" }
        let last = p.split(separator: "/").last.map(String.init) ?? ""
        return last.contains(".") ? p : "index.html"
    }

    static func mime(_ path: String) -> String {
        switch (path as NSString).pathExtension.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json", "webmanifest": return "application/json; charset=utf-8"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "ico": return "image/x-icon"
        case "wasm": return "application/wasm"
        case "woff2": return "font/woff2"
        case "gz": return "application/gzip"
        case "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url else { return task.didFailWithError(URLError(.badURL)) }
        let id = ObjectIdentifier(task)
        let isHead = task.request.httpMethod == "HEAD"
        io.async { [weak self] in
            guard let self = self else { return }
            var status = 404
            var data = Data()
            var type = "text/plain; charset=utf-8"
            if let root = self.root, let path = AssetSchemeHandler.assetPath(url.path),
               let d = try? Data(contentsOf: root.appendingPathComponent(path), options: .mappedIfSafe) {
                status = 200
                data = d
                type = AssetSchemeHandler.mime(path)
            }
            DispatchQueue.main.async {
                if self.stopped.remove(id) != nil { return }
                let headers = ["Content-Type": type, "Content-Length": "\(data.count)", "Cache-Control": "no-cache", "Access-Control-Allow-Origin": "*"]
                guard let resp = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) else {
                    return task.didFailWithError(URLError(.cannotParseResponse))
                }
                task.didReceive(resp)
                if !isHead && !data.isEmpty { task.didReceive(data) }
                task.didFinish()
            }
        }
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {
        stopped.insert(ObjectIdentifier(task))
    }
}
